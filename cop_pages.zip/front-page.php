<?php
/**
 * Front page template
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mobile branch: render the Home (Mobile Service) template
 * instead of the desktop landing page.
 */
if ( wp_is_mobile() ) {
	locate_template( 'page-templates/template-home-mobile.php', true, false );
	return;
}

$featured_items = require get_template_directory() . '/inc/home-featured-items.php';

if ( is_array( $featured_items ) ) {
	shuffle( $featured_items );
	$featured_items = array_slice( $featured_items, 0, 5 );
} else {
	$featured_items = array();
}

get_header();
?>

<div class="home-page">

	<div class="home-desktop-landing">

		<div class="landing-background" data-home-url="<?php echo esc_url( home_url( '/' ) ); ?>">

			<div class="landing-overlay"></div>

			<main class="landing-content">
				<div class="landing-content-row">
					<div class="landing-intro-content">
						<div class="landing-copy landing-copy--desktop">
							<?php get_template_part( 'template_parts/intro', 'desktop' ); ?>
						</div>

						<div class="landing-copy landing-copy--laptop">
							<?php get_template_part( 'template_parts/intro', 'laptop' ); ?>
						</div>
					</div>

					<?php if ( ! empty( $featured_items ) ) : ?>
						<aside class="landing-featured-panel" aria-label="Featured documents">

							<div class="featured-carousel js-featured-carousel">
								<div class="featured-carousel__track">
									<?php foreach ( $featured_items as $index => $item ) : ?>
										<?php
										$title   = isset( $item['title'] ) ? $item['title'] : '';
										$url     = isset( $item['url'] ) ? $item['url'] : '';
										$excerpt = isset( $item['excerpt'] ) ? $item['excerpt'] : '';
										$image   = isset( $item['image'] ) ? $item['image'] : '';
										?>
										<article class="featured-carousel__slide<?php echo 0 === $index ? ' is-active' : ''; ?>" aria-hidden="<?php echo 0 === $index ? 'false' : 'true'; ?>">
											<?php if ( ! empty( $image ) ) : ?>
												<div class="featured-carousel__image-wrap">
													<a href="<?php echo esc_url( $url ); ?>" class="featured-carousel__image-link" target="_blank" rel="noopener noreferrer">
														<img
															class="featured-carousel__image"
															src="<?php echo esc_url( $image ); ?>"
															alt="<?php echo esc_attr( $title ); ?>"
														>
													</a>
												</div>
											<?php endif; ?>

											<h3 class="featured-carousel__title">
												<a href="<?php echo esc_url( $url ); ?>" class="featured-carousel__title-link" target="_blank" rel="noopener noreferrer">
													<?php echo esc_html( $title ); ?>
												</a>
											</h3>

											<?php if ( ! empty( $excerpt ) ) : ?>
												<div class="featured-carousel__excerpt-wrap">
													<div class="featured-carousel__excerpt is-collapsed">
														<?php echo nl2br( esc_html( $excerpt ) ); ?>
													</div>
													<button type="button" class="featured-carousel__more-btn" aria-expanded="false">
														More
													</button>
												</div>
											<?php endif; ?>
										</article>
									<?php endforeach; ?>
								</div>

								<?php if ( count( $featured_items ) > 1 ) : ?>
									<div class="featured-carousel__controls">
										<button type="button" class="featured-carousel__nav featured-carousel__nav--prev" aria-label="Previous featured paper">
											Previous
										</button>

										<div class="featured-carousel__dots" aria-hidden="true">
											<?php foreach ( $featured_items as $index => $item ) : ?>
												<span class="featured-carousel__dot<?php echo 0 === $index ? ' is-active' : ''; ?>"></span>
											<?php endforeach; ?>
										</div>

										<button type="button" class="featured-carousel__nav featured-carousel__nav--next" aria-label="Next featured paper">
											Next
										</button>
									</div>
								<?php endif; ?>

								<p class="featured-carousel__register">
									Please
									<a href="<?php echo esc_url( home_url( '/?registration_modal=1' ) ); ?>" data-open-registration-modal>
										register
									</a>
									(or login) to view more content
								</p>
							</div>
						</aside>
					<?php endif; ?>
				</div>
				
				<p class="visually-muted">Glandore is the working name of Glandore Associates.</p>
				
			</main>

		</div>

	</div><!-- .home-desktop-landing -->

</div><!-- .home-page -->

<?php
// Login modal: front page only, RHS panel containing URM login form.
?>
<div class="login-modal-overlay" id="login-modal-overlay" hidden></div>

<div class="login-modal-panel" id="login-modal-panel" hidden role="dialog" aria-modal="true" aria-labelledby="login-modal-title">
	<div class="login-modal-inner">
		<button type="button" class="login-modal-close" id="login-modal-close" aria-label="Close login panel">×</button>

		<h2 id="login-modal-title" class="login-modal-heading">Member login</h2>

		<div class="login-modal-form">
			<?php echo do_shortcode( '[user_registration_login]' ); ?>
		</div>
	</div>
</div>

<?php get_template_part( 'template_parts/modals/modal-registration' ); ?>

<script>
(function () {
  "use strict";

  if (window.location.search.indexOf("urm_error=ur_login_error_") === -1) {
    return;
  }

  var overlay = document.getElementById("login-modal-overlay");
  var panel   = document.getElementById("login-modal-panel");

  if (overlay) {
    overlay.hidden = false;
  }
  if (panel) {
    panel.hidden = false;
  }
})();
</script>

<?php get_footer(); ?>