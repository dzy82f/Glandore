<?php
/**
 * File: /wp-content/themes/glandore/inc/enqueue-assets.php
 *
 * Purpose:
 * - Single, deterministic front-end asset pipeline
 * - Ensure cop.css loads LAST (after style.css and mobile.css)
 * - Enqueue front-page-only home carousel JS when present
 *
 * @package glandore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_enqueue_scripts', 'glandore_enqueue_assets', 1000 );

function glandore_enqueue_assets() : void {

	$theme_dir = get_stylesheet_directory();
	$theme_uri = get_stylesheet_directory_uri();

	// -----------------------------
	// 1) Main theme stylesheet
	// -----------------------------
	wp_enqueue_style(
		'glandore-style-css',
		$theme_uri . '/style.css',
		array(),
		filemtime( $theme_dir . '/style.css' )
	);

	// -----------------------------
	// 2) Mobile layer (always)
	// -----------------------------
	$mobile_rel  = '/assets/css/mobile.css';
	$mobile_path = $theme_dir . $mobile_rel;

	if ( file_exists( $mobile_path ) ) {
		wp_enqueue_style(
			'glandore-mobile-css',
			$theme_uri . $mobile_rel,
			array( 'glandore-style-css' ),
			filemtime( $mobile_path )
		);
	}

	// -----------------------------
	// 3) Front page featured carousel JS
	// -----------------------------
	if ( is_front_page() ) {
		$carousel_rel  = '/assets/js/home-carousel.js';
		$carousel_path = $theme_dir . $carousel_rel;

		if ( file_exists( $carousel_path ) ) {
			wp_enqueue_script(
				'glandore-home-carousel',
				$theme_uri . $carousel_rel,
				array(),
				filemtime( $carousel_path ),
				true
			);
		}
	}
	
	// -----------------------------
	// 4) CoP layer (MUST BE LAST)
	// -----------------------------
	$cop_rel  = '/assets/css/cop.css';
	$cop_path = $theme_dir . $cop_rel;

	// Defensive: if anything else enqueued it earlier, remove it.
	wp_dequeue_style( 'glandore-cop-css' );
	wp_deregister_style( 'glandore-cop-css' );

	if ( file_exists( $cop_path ) ) {
		wp_enqueue_style(
			'glandore-cop-css',
			$theme_uri . $cop_rel,
			array( 'glandore-mobile-css', 'glandore-style-css' ),
			filemtime( $cop_path )
		);
	}
}